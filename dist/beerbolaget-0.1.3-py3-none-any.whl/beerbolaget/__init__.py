﻿"""
A python package to get information about the latest beer available at Systembolaget.

This code is released under the terms of the MIT license. See the LICENSE
file for more details.
"""