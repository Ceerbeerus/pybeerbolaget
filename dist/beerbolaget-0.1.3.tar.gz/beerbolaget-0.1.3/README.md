﻿# beerbolaget

_A python package to get information about the latest beer available at Systembolaget in Sweden._

Documentation:

https://github.com/Ceerbeerus/beerbolaget